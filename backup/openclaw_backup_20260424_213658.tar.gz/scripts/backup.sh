#!/bin/bash

# Script de backup para OpenClaw Docker
# Usa backup local dentro do diretório do projeto

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKUP_DIR="$PROJECT_ROOT/backup"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Criar diretório de backup local
mkdir -p "$BACKUP_DIR"

echo "=== Backup OpenClaw $TIMESTAMP ==="

# Backup da configuração OpenClaw
if [ -d "$PROJECT_ROOT/openclaw/.openclaw/config" ]; then
    CONFIG_SRC="$PROJECT_ROOT/openclaw/.openclaw/config"
    CONFIG_DST="$BACKUP_DIR/config-$TIMESTAMP"
    mkdir -p "$CONFIG_DST"
    cp -r "$CONFIG_SRC/"* "$CONFIG_DST/" 2>/dev/null || true
    echo "  - Config OpenClaw: $CONFIG_SRC -> $CONFIG_DST"
fi

# Backup do Docker Compose
cp "$PROJECT_ROOT/docker-compose.yml" "$BACKUP_DIR/" 2>/dev/null || true
echo "  - docker-compose.yml"

# Backup do Dockerfile e scripts
cp "$PROJECT_ROOT/Dockerfile" "$BACKUP_DIR/" 2>/dev/null || true
cp "$PROJECT_ROOT/entrypoint.js" "$BACKUP_DIR/" 2>/dev/null || true
cp "$PROJECT_ROOT/backup.sh" "$BACKUP_DIR/" 2>/dev/null || true
cp "$PROJECT_ROOT/settings.json" "$BACKUP_DIR/" 2>/dev/null || true
echo "  - Dockerfile, entrypoint.js, backup.sh, settings.json"

# Criar arquivo de backup combinado
ARCHIVE="$BACKUP_DIR/openclaw-$TIMESTAMP.tar.gz"
tar -czf "$ARCHIVE" \
    -C "$BACKUP_DIR" \
    config-$TIMESTAMP \
    docker-compose.yml \
    Dockerfile \
    entrypoint.js \
    backup.sh \
    settings.json 2>/dev/null

echo ""
echo "Backup concluído em: $BACKUP_DIR"
echo "Arquivo principal: $ARCHIVE"
echo ""
echo "Tamanho do backup: $(du -h "$ARCHIVE" 2>/dev/null | cut -f1 || echo 'N/A')"
echo ""
echo "Para restaurar:"
echo "  1. rm -rf backup/*"
echo "  2. tar -xzf $ARCHIVE -C ."
echo "  3. npm install"
echo "  4. docker-compose up -d"
