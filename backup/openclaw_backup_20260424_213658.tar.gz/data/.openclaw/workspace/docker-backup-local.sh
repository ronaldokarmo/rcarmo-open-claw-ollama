#!/bin/bash
# 🔧 Script de Backup para OpenClaw Workspace
# 🔐 Cria backups automáticos no workspace atual

# Configurações
BACKUP_DIR="/home/openclaw/.openclaw/workspace/docker-backups"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
DATADIR="/home/openclaw/.openclaw"

# 📦 Criar diretório de backup
mkdir -p "$BACKUP_DIR" || {
  echo "❌ Erro: Não foi possível criar diretório de backups"
  exit 1
}

# 1️⃣ Backup de Workspace (scripts, config, logs)
echo "📂 Fazendo backup do workspace atual..."
mkdir -p "${BACKUP_DIR}/workspace-${TIMESTAMP}"
find "${DATADIR}/workspace" -maxdepth 1 -name "*.sh" -o -name "*.md" -o -name "*.py" -o -name "*.json" 2>/dev/null | while read file; do
  if [[ -f "$file" ]]; then
    cp "$file" "${BACKUP_DIR}/workspace-${TIMESTAMP}/" 2>/dev/null
  fi
done

# 2️⃣ Backup de Docker Compose
echo "🐳 Fazendo backup dos containers..."
if [[ -f "${DATADIR}/docker-compose.yml" ]]; then
  cp "${DATADIR}/docker-compose.yml" "${BACKUP_DIR}/docker-compose-${TIMESTAMP}.yml"
fi

# 3️⃣ Backup dos logs recentes (últimos 7 dias)
echo "📋 Fazendo backup de logs recentes..."
if [[ -d "${DATADIR}/logs" ]]; then
  LOGBACKUP_DIR="${BACKUP_DIR}/logs-${TIMESTAMP}"
  mkdir -p "$LOGBACKUP_DIR"
  find "${DATADIR}/logs" -name "*.log" -mtime -7 -exec cp {} "$LOGBACKUP_DIR/" \; 2>/dev/null || true
fi

# 4️⃣ Backup de Scripts
echo "📜 Fazendo backup de scripts do workspace..."
if [[ -d "${DATADIR}/workspace" ]]; then
  SCRIPTS_DIR="${BACKUP_DIR}/scripts-${TIMESTAMP}"
  mkdir -p "$SCRIPTS_DIR"
  find "${DATADIR}/workspace" -maxdepth 1 -name "*.sh" -type f -exec cp {} "$SCRIPTS_DIR/" \; 2>/dev/null || true
fi

# 5️⃣ Relatório
echo ""
echo "✅ ======================================="
echo "✅ Backup Concluído com Sucesso!"
echo "✅ ======================================="
echo "📍 Localização: $BACKUP_DIR"
echo "📅 Data do Backup: $(date '+%d/%m/%Y %H:%M')"
echo "📦 Arquivos Criados:"
ls -la "${BACKUP_DIR}"/"*-${TIMESTAMP}"/*.yml 2>/dev/null | tail -n +2 | awk '{print "  - " $NF}' || true
ls -la "${BACKUP_DIR}"/"*-${TIMESTAMP}"/*.sh 2>/dev/null | tail -n +2 | awk '{print "  - " $NF}' || true
echo "  (Logs e scripts backupados se existir)"
echo "=="
