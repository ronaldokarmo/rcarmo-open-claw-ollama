#!/bin/bash
# 🧹 Script de Limpeza de Backups Antigos
# Remove backups com mais de 7 dias

BACKUP_DIR="/home/openclaw/.openclaw/workspace/docker-backups"
DAYS_TO_KEEP=7

echo "🧹 Iniciando limpeza de backups..."
echo "📍 Diretório: $BACKUP_DIR"
echo "📅 Manter últimos: $DAYS_TO_KEEP dias"
echo ""

# Verificar se diretório existe
if [[ ! -d "$BACKUP_DIR" ]]; then
  echo "❌ Diretório de backup não encontrado: $BACKUP_DIR"
  exit 1
fi

# Contar backups antes
BEFORE_COUNT=$(find "$BACKUP_DIR" -maxdepth 1 -type d -name "*-[0-9]*" | wc -l)
echo "📦 Backups encontrados: $BEFORE_COUNT"

# Remover diretórios mais antigos que N dias
deleted=0
find "$BACKUP_DIR" -maxdepth 1 -type d -name "*-[0-9]*" -mtime +$DAYS_TO_KEEP | while read dir; do
  if [[ -d "$dir" ]]; then
    echo "  🗑️  Removendo: $(basename "$dir")"
    rm -rf "$dir"
    ((deleted++))
  fi
done

# Contar backups depois
AFTER_COUNT=$(find "$BACKUP_DIR" -maxdepth 1 -type d -name "*-[0-9]*" | wc -l)

# Calcular espaço liberado (aproximado)
SPACE_USED=$(du -sh "$BACKUP_DIR" | cut -f1)

echo ""
echo "✅ ======================================="
echo "✅ Limpeza Concluída!"
echo "✅ ======================================="
echo "📦 Backups restantes: $AFTER_COUNT"
echo "💾 Espaço usado: $SPACE_USED"
echo "🗑️  Backups removidos: $((BEFORE_COUNT - AFTER_COUNT))"
echo "=="
