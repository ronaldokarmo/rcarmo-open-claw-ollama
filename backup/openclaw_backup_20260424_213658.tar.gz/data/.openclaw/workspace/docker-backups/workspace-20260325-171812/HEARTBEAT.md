# HEARTBEAT.md

# Automated Task Checklist for aton (Cyber-Gryphon)

- [x] **Log Cleanup**: Check the size of `debug.log`. If larger than 50MB, rotate or truncate.
- [x] **Memory Sync**: Review notes from the last 2 days in `memory/` and distill important learnings into `MEMORY.md`.
- [x] **Home Assistant Monitor**: Atribuído ao Agente tutor-iot para monitoramento periódico.
- [x] **System Status**: Check host disk space and memory usage.
- [x] **Proactivity**: No alerts needed.

## Agente Tutor-IOT Atualizado
- **Responsável**: Monitoramento de DOIS Home Assistant:
  1. **Estável (VirtualBox)**: `http://homeassistant:8123` (prioritário)
  2. **Testes (OrangePi)**: `rcarmo-iot.duckdns.org:8123`
- **Tarefas**: Verificação de conectividade, status do serviço, tempos de resposta, notificações via Telegram
- **Frequência**: Verificações periódicas a cada 15 minutos
- **Prioridade**: Ambiente estável (VirtualBox) tem notificações prioritárias

# Note: To deactivate the heartbeat, leave this file with only comments.
