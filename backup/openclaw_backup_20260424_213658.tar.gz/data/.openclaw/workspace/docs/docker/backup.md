# Guia de Backup para OpenClaw Docker

## 📋 Visão Geral

Este documento contém instruções completas para fazer backup dos containers Docker, volumes e configurações do OpenClaw.

## 🔧 Pré-requisitos

- Acesso ao servidor onde estão os containers Docker
- Docker instalado e rodando
- Espaço de armazenamento suficiente para o backup

## 📦 O que Backup

Os seguintes componentes devem ser incluídos no backup:

1. **Imagens Docker** - Imagens do OpenClaw e dependências
2. **Volumes** - Dados persistentes (banco de dados, logs, configurações)
3. **Configurações** - Comandos, variáveis de ambiente, volumes montados
4. **Containers** - Estado dos containers (opcional)

## 🛠️ Processo de Backup

### 1. Backup dos Volumes (DADOS CRÍTICOS)

```bash
# Listar volumes
docker volume ls -f openclaw

# Backup de um volume específico
docker run --rm -v openclaw_db_data:/data -v $(pwd):/backup alpine tar czf /backup/db-backup-$(date +%Y%m%d-%H%M%S).tar.gz /data

# Backup de múltiplos volumes
docker run --rm \
  -v openclaw_db_data:/data \
  -v openclaw_logs:/logs \
  -v $(pwd):/backup \
  alpine tar czf /backup/all-volumes-$(date +%Y%m%d-%H%M%S).tar.gz /data /logs
```

### 2. Backup das Imagens

```bash
# Listar imagens
docker images

# Salvar imagens como archive (compactado)
docker save -o openclaw-images-$(date +%Y%m%d-%H%M%S).tar openclaw:latest

# Backup de todas as imagens
docker save -o all-openclaw-images-$(date +%Y%m%d-%H%M%S).tar \
  openclaw \
  python \
  node
  # adicione outras imagens necessárias
```

### 3. Backup das Configurações

```bash
# Backup do docker-compose.yml
cp /path/to/docker-compose.yml /path/to/backups/docker-compose-$(date +%Y%m%d-%H%M%S).yml

# Backup das configurações do OpenClaw
tar czf openclaw-config-$(date +%Y%m%d-%H%M%S).tar.gz \
  /path/to/openclaw/.openclaw/config/
```

### 4. Backup Completo (Script Automatizado)

Crie um script `backup.sh`:

```bash
#!/bin/bash
BACKUP_DIR="/backup/openclaw"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

mkdir -p $BACKUP_DIR

# Backup de volumes
docker run --rm \
  -v openclaw_db_data:/data \
  -v $(pwd):/backup \
  alpine tar czf /backup/all-data-$TIMESTAMP.tar.gz /data

# Backup de imagens
docker save -o $BACKUP_DIR/images-$TIMESTAMP.tar openclaw:latest

# Backup de configurações
cp docker-compose.yml $BACKUP_DIR/
tar czf $BACKUP_DIR/config-$TIMESTAMP.tar.gz openclaw/.openclaw/config/

echo "Backup concluído em $BACKUP_DIR"
```

## 📝 Checklist de Backup

- [ ] Volumes de banco de dados
- [ ] Volumes de logs
- [ ] Volumes de uploads/arquivos
- [ ] Imagens dos containers
- [ ] Arquivo docker-compose.yml
- [ ] Arquivos .env
- [ ] Configurações personalizadas

## 💾 Armazenamento de Backups

Recomendações:

1. **Backup Local** - Disco externo ou partição separada
2. **Backup Remoto** - Servidor externo ou nuvem
3. **Retenção** - Mantenha backups por 30-90 dias
4. **Verificação** - Teste restauração trimestral

## 🔍 Exemplo: Backup Automático Diário

```bash
# Adicionar ao crontab (rodar às 3h da manhã)
0 3 * * * /home/openclaw/.openclaw/workspace/scripts/backup-docker.sh >> /var/log/backup.log 2>&1
```

## ✅ Verificação Pós-Backup

```bash
# Verificar tamanho do backup
ls -lh /backup/openclaw/*.tar.gz

# Verificar integridade
tar tzf /backup/openclaw/all-data-*.tar.gz | head -20

# Listar todos os backups recentes
ls -lt /backup/openclaw/*.tar.gz
```

---
*Documento mantido automaticamente pelo sistema de backup do OpenClaw*
