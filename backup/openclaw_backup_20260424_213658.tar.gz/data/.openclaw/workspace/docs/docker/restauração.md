# Guia de Restauração para OpenClaw Docker

## 📋 Visão Geral

Este documento contém instruções passo a passo para restaurar o ambiente OpenClaw Docker após um backup.

## ⚠️ Antes de Começar

- **Backup válido** - Tenha certeza de que o backup está íntegro
- **Espaço disponível** - Disco com espaço suficiente
- **Acesso administrativo** - Sudo ou root access
- **Docker rodando** - Verifique se o Docker está ativo

## 🎯 Cenários de Restauração

1. **Restauração Completa** - Do zero, com todos os componentes
2. **Restauração Parcial** - Apenas volumes de dados
3. **Restauração de Imagens** - Apenas recuperação de imagens Docker
4. **Recuperação de Emergência** - Quando containers estão corrompidos

## 📦 Restauração Passo a Passo

### Cenário 1: Restauração Completa (Do Zero)

#### Pré-requisitos

```bash
# Verificar Docker e Docker Compose
docker --version
docker-compose --version

# Limpar espaço se necessário
docker system prune -a
```

#### Carregar Backups

```bash
# Extrair backup de volumes
tar xzf /backup/openclaw/all-data-YYYYMMDD-HHMMSS.tar.gz -C /destino/

# Carregar imagens Docker (se necessário)
docker load -i /backup/openclaw/images-YYYYMMDD-HHMMSS.tar
```

#### Recarregar Configurações

```bash
# Restabelecer docker-compose.yml
cp /backup/openclaw/docker-compose.yml /path/to/current/compose/

# Restabelecer arquivos .env
cp /backup/openclaw/.env /path/to/current/env/

# Configurar volumes
docker volume create --name openclaw_db_data /destino/volumes/db
docker volume create --name openclaw_logs /destino/volumes/logs
```

#### Iniciar Containers

```bash
# Restaurar configurações de volumes (opcional, se necessário)
docker run --rm -v openclaw_db_data:/data -v /destino/volumes/db:/backup alpine \
  cp -r /backup/* /data/

# Iniciar containers
docker-compose up -d

# Verificar status
docker-compose ps
```

#### Verificar Restauração

```bash
# Testar conexão com banco de dados
docker-compose exec db python -c "import sqlite3; print(sqlite3.connect('database.db'))"

# Verificar logs
docker-compose logs -f

# Executar saúde checks
docker-compose exec app python /app/scripts/healthcheck.py
```

### Cenário 2: Apenas Restauração de Dados

```bash
# Extrair backup de dados
tar xzf /backup/openclaw/all-data-YYYYMMDD-HHMMSS.tar.gz -C /destino/

# Restaurar volumes
docker run --rm \
  -v openclaw_db_data:/data \
  -v /destino/volumes/db:/backup \
  alpine \
  cp -r /backup/* /data/

# Recarregar containers existentes
docker-compose up -d --no-recreate --no-deps

# Sincronizar timestamps
find /destino/volumes -exec touch {} \;
```

### Cenário 3: Recuperação de Emergência

```bash
# Parar tudo
docker-compose down

# Limpar volumes corrompidos (se necessário)
docker volume rm openclaw_db_data
docker volume create openclaw_db_data /destino/volumes/db

# Restaurar dados
tar xzf /backup/openclaw/all-data-YYYYMMDD-HHMMSS.tar.gz -C /destino/

# Reconstruir containers
docker-compose up -d --force-recreate

# Monitorar inicialização
docker-compose logs -f app
```

## 🔍 Validação Pós-Restauração

### Checklist de Verificação

- [ ] Containers estão rodando
- [ ] Banco de dados é acessível
- [ ] Arquivos de logs existem
- [ ] Aplicação responde a requisições
- [ ] Autenticação funcionando
- [ ] Permissões de arquivo corretas

### Comandos de Validação

```bash
# Verificar status dos containers
docker-compose ps

# Testar API
curl http://localhost:3000/health

# Verificar logs recentes
docker-compose logs --tail 50

# Testar banco de dados
docker-compose exec db sqlite3 database.db "SELECT COUNT(*) FROM users;"

# Verificar integridade de arquivos
find /destino/volumes -type f -exec ls -lh {} \;
```

## 🐛 Troubleshooting

### Containers não iniciam

```bash
# Verificar logs
docker-compose logs -f

# Resetar redes
docker network rm openclaw_default
docker network create openclaw_default

# Reiniciar tudo
docker-compose down
docker-compose up -d
```

### Permissões de arquivo

```bash
# Ajustar permissões
chown -R $(whoami):$(whoami) /destino/volumes
chmod -R 755 /destino/volumes

# Alternativamente, usar volumes do host
docker-compose down
docker-compose up -d
```

### Banco de dados corrompido

```bash
# Backup atual corrompido, restaurar backup anterior
tar xzf /backup/openclaw/older-backup.tar.gz -C /destino/

# Ou reconstruir banco
docker-compose exec db dropdb database.db
docker-compose exec db createdb database.db
```

## 💾 Estratégia de Restauração

### Hierarquia de Prioridade

1. **Backup mais recente** - Tentar primeiro
2. **Backup anterior** - Se mais recente falhar
3. **Backup de 24h antes** - Caso haja dados críticos perdidos

### Retenção de Backups

- **Backups diários** - Manter por 7 dias
- **Backups semanais** - Manter por 4 semanas
- **Backups mensais** - Manter por 12 meses
- **Backup mensal completo** - Manter indefinidamente

## 📝 Checklist de Restauração

### Antes de Restaurar

- [ ] Identificar motivo da restauração
- [ ] Selecionar backup apropriado
- [ ] Ter espaço de disco suficiente
- [ ] Ter acesso à rede
- [ ] Notar se há dependências de sistema

### Durante a Restauração

- [ ] Parar containers existentes
- [ ] Limpar volumes corrompidos
- [ ] Extrair backup de dados
- [ ] Carregar imagens Docker
- [ ] Restabelecer configurações
- [ ] Iniciar containers

### Após Restauração

- [ ] Verificar status de todos os containers
- [ ] Testar funcionalidades principais
- [ ] Verificar integridade de dados
- [ ] Testar autenticação e login
- [ ] Validar backups de dados
- [ ] Documentar o ocorrido

## 🔄 Próximos Passos

1. **Teste de Restauração** - Pratique trimestralmente
2. **Atualização de Backups** - Verifique integridade
3. **Limpeza de Backups Antigos** - Remova backups de teste
4. **Ajuste de Retenção** - Revise política de retenção

## 🆘 Suporte

- Documentação oficial: https://docs.openclaw.ai
- Discord Community: https://discord.com/invite/clawd
- Repositório: https://github.com/openclaw/openclaw

---
*Documento mantido automaticamente pelo sistema de backup do OpenClaw*
