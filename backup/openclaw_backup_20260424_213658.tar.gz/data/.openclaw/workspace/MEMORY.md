# MEMORY.md - Long-Term Memory (LTM)

## 👤 User Profile: Ronaldo do Carmo
- **ID**: `1457522952` (Telegram)
- **Occupation**: Test Engineer (Engenheiro de Testes)
- **Primary Channel**: Telegram (verified with audio)
- **Timezone**: America/Sao_Paulo (GMT-3)
- **Style**: Tech-savvy, values efficiency, interested in advanced automation and persistence.

## 🛠 Tech Stack & Projects
- **Current Focus**: OpenClaw optimization, Memory Persistence, Heartbeat automation.
- **Home Automation**: Home Assistant integration (`rcarmo-iot.duckdns.org`).
- **Keywords**: Telegram integration, TTS, persistence, memory distillation, IoT, Home Assistant.

## 🧠 Lessons Learned & Preferences
- **Audio Integration**: Audio tests (TTS/Voice) are confirmed working on Telegram.
- **Sync Code**: Uses sync codes (e.g., "ABACAXI", "9MVS1J51GMK6") for environment verification.

## 📈 Long-term Goals
1. Optimize Atlas's memory and persistence systems.
2. Implement robust autonomous task handling via Heartbeats.
3. [Pending] Integrate calendar and external task management.
4. Expand Testing Snippets and English Glossary.

---
*Last Updated: 2026-04-03*
