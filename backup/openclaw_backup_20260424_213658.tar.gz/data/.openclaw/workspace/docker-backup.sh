#!/bin/bash
# 🔧 Script de Backup para OpenClaw Docker
# 🔐 Cria backups automáticos das configurações, logs e agentes

# Configurações
BACKUP_ROOT="/mnt/e/openclaw-docker/data/.openclaw"
BACKUP_DIR="${BACKUP_ROOT}/backups"
DATADIR="${BACKUP_ROOT}"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

# 🔍 Verificar se temos acesso aos caminhos
check_access() {
  if [[ ! -r "$BACKUP_ROOT" ]]; then
    echo "❌ Erro: Sem permissão para acessar $BACKUP_ROOT"
    exit 1
  fi
}

# 📦 Função para fazer backup com segurança
backup_with_copy() {
  local source="$1"
  local dest="$2"
  
  if [[ -d "$source" ]]; then
    echo "  📁 Backup de diretório: $source → $dest"
    # Copiar mantendo estrutura (ignora paths relativos absolutos)
    mkdir -p "$(dirname "$dest")"
    find "$source" -mindepth 1 -maxdepth 1 ! -name '*[.,]??*[-]??*' -exec cp -P {} "$dest/" \; 2>/dev/null
  fi
}

# 🛡️ Criar diretório de backup
mkdir -p "$BACKUP_DIR" || {
  echo "❌ Erro: Não foi possível criar diretório de backups"
  exit 1
}

# 1️⃣ Backup de Configurações
echo "🔧 Fazendo backup de configurações..."
if [[ -d "${DATADIR}/config" ]]; then
  backup_with_copy "${DATADIR}/config" "${BACKUP_DIR}/config-${TIMESTAMP}"
fi

# 2️⃣ Backup de Logs (últimos 30 dias apenas)
echo "📋 Fazendo backup de logs recentes..."
if [[ -d "${DATADIR}/logs" ]]; then
  LOGBACKUP_DIR="${BACKUP_DIR}/logs-${TIMESTAMP}"
  mkdir -p "$LOGBACKUP_DIR"
  find "${DATADIR}/logs" -name "*.log" -mtime -30 -exec cp {} "$LOGBACKUP_DIR/" \; 2>/dev/null || true
fi

# 3️⃣ Backup de Agents
echo "🤖 Fazendo backup de agentes..."
if [[ -d "${DATADIR}/agents" ]]; then
  backup_with_copy "${DATADIR}/agents" "${BACKUP_DIR}/agents-${TIMESTAMP}"
fi

# 4️⃣ Backup de Scripts
echo "📜 Fazendo backup de scripts..."
if [[ -d "${DATADIR}/scripts" ]]; then
  backup_with_copy "${DATADIR}/scripts" "${BACKUP_DIR}/scripts-${TIMESTAMP}"
fi

# 5️⃣ Backup de OpenClaw Workspace
echo "📂 Fazendo backup do workspace..."
if [[ -d "${DATADIR}/openclaw" ]]; then
  backup_with_copy "${DATADIR}/openclaw" "${BACKUP_DIR}/openclaw-${TIMESTAMP}"
fi

# 6️⃣ Limpeza de backups antigos
echo "🧹 Limpando backups antigos (mantendo últimos 10)..."
cd "$BACKUP_DIR" || exit
ls -t *.tar.gz 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true
ls -t */*-$(date +%Y%m%d) 2>/dev/null | tail -n +11 | xargs rm -rf 2>/dev/null || true

# 📝 Relatório
echo ""
echo "✅ ======================================="
echo "✅ Backup Concluído com Sucesso!"
echo "✅ ======================================="
echo "📍 Localização: $BACKUP_DIR"
echo "📅 Data do Backup: $(date '+%d/%m/%Y %H:%M')"
echo "📦 Arquivos Criados:"
ls -lah "${BACKUP_DIR}"/"*-${TIMESTAMP}" 2>/dev/null | tail -n +3 | awk '{print "  - " $NF}' || echo "  (nenhum backup para mostrar)"
echo "======================================="
