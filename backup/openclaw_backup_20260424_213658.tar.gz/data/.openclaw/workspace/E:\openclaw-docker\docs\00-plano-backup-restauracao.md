# Plano de Backup e Restauração - OpenClaw Docker

## Visão Geral
Este documento descreve os procedimentos de backup e restauração para o sistema OpenClaw Docker.

**Estrutura de Pastas:**
```
E:\openclaw-docker\
├── docker-compose.yml
├── dockerfile
├── docs\              # Esta pasta de documentação
└── data\.openclaw\    # Dados do OpenClaw
```

---

## PARTE 1: BACKUP

### 1.1 Identificação de Dados a Backupar

**Volume Docker Principal:** `data\.openclaw\`
Contém:
- Configurações do OpenClaw
- Arquivos de memória (MEMORY.md, SOUL.md, etc.)
- Logs e dados de sessão
- Scripts de automação

**Volume Secundário (caso exista):**
- Configurações do sistema Host (opcional)
- Backups anteriores

### 1.2 Estrutura de Backup Recomendada

```
E:\backups\openclaw\
├── {data}\              # Backup do volume .openclaw
│   ├── .openclaw\
│   ├── config\
│   ├── memory\
│   └── scripts\
├── manifests\
│   ├── docker-compose.yml
│   └── Dockerfile
└── metadata\
    ├── backup-manifest-{timestamp}.json
    └── checksums.sha256
```

### 1.3 Script de Backup Automatizado

**Criação do script de backup:**

```batch
@echo off
REM Backup de OpenClaw - Script Automático
setlocal enabledelayedexpansion

set BACKUP_SOURCE=E:\openclaw-docker\data\.openclaw
set BACKUP_TARGET=E:\backups\openclaw\.openclaw
set COMPOSE_FILE=E:\openclaw-docker\docker-compose.yml
set DOCKERFILE_FILE=E:\openclaw-docker\dockerfile

REM Criar pasta de backup se não existir
if not exist "%BACKUP_TARGET%" mkdir "%BACKUP_TARGET%"
if not exist "E:\backups\openclaw\manifests" mkdir "E:\backups\openclaw\manifests"
if not exist "E:\backups\openclaw\metadata" mkdir "E:\backups\openclaw\metadata"

REM Verificar status do Docker
docker ps >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Docker não está rodando!
    exit /b 1
)

REM Copiar dados do volume
echo [INFO] Criando backup dos dados...
xcopy "%BACKUP_SOURCE%" "%BACKUP_TARGET%\_latest" /E /I /Y

REM Backup dos arquivos de configuração
xcopy "%COMPOSE_FILE%" "E:\backups\openclaw\manifests\" /Y
xcopy "%DOCKERFILE_FILE%" "E:\backups\openclaw\manifests\" /Y

REM Gerar checksum
cd "E:\backups\openclaw\.openclaw\_latest"
powershell -Command "Get-FileHash . -Algorithm SHA256 | Select-Object Hash,Path" > ..\metadata\checksums.sha256

REM Criar manifest do backup
powershell -Command @"
    $date = Get-Date -Format 'yyyyMMdd-HHmmss'
    $manifest = @{
        'timestamp' = $date
        'source' = 'E:\openclaw-docker\data\.openclaw'
        'size' = (Get-ChildItem -Recurse -Path '.openclaw\_latest' -File).Length
        'status' = 'success'
    } | ConvertTo-Json -Depth 5
    $manifest | Out-File -Path 'E:\backups\openclaw\manifests\backup-manifest-%date%.json'
"@

REM Limpar backup anterior
if exist "E:\backups\openclaw\.openclaw\_old" rmdir /s /q "E:\backups\openclaw\.openclaw\_old"
ren "%BACKUP_TARGET%" "_old"

echo [OK] Backup realizado com sucesso!
echo Backup salvo em: %BACKUP_TARGET%
```

### 1.4 Procedimento de Backup Manual

**Passo a Passo:**

1. **Verificar status do sistema:**
   ```batch
   docker-compose ps
   docker system df
   ```

2. **Executar backup:**
   ```batch
   docker run --rm -v openclaw_data:/data -v C:/path/to/backup:/backup alpine cp -r /data/* /backup/
   ```

3. **Validar checksum:**
   ```batch
   sha256sum E:\backups\openclaw\.openclaw\_latest\* > E:\backups\openclaw\metadata\checksums.sha256
   ```

---

## PARTE 2: RESTAURAÇÃO

### 2.1 Preparação para Restauração

**Checklist Pré-Restauração:**
- [ ] Parar contêineres: `docker-compose down`
- [ ] Remover volumes existentes (se necessário)
- [ ] Garantir espaço em disco suficiente
- [ ] Ter backup válido disponível
- [ ] Documentar estado atual antes de iniciar

### 2.2 Procedimento de Restauração

**Passo a Passo:**

1. **Parar o sistema atual:**
   ```batch
   docker-compose -f E:\openclaw-docker\docker-compose.yml down -v
   ```

2. **Restaurar do backup:**
   ```batch
   # Restaurar dados
   robocopy E:\backups\openclaw\.openclaw\_latest\ E:\openclaw-docker\data\.openclaw\ /E /I /Y

   # Restaurar configurações (se aplicável)
   robocopy E:\backups\openclaw\manifests\ E:\openclaw-docker\ /E /I /Y
   ```

3. **Reiniciar o sistema:**
   ```batch
   docker-compose -f E:\openclaw-docker\docker-compose.yml up -d
   ```

4. **Verificar status:**
   ```batch
   docker-compose ps
   docker-compose logs
   ```

### 2.3 Procedimento de Restauração Completa (Reinstalação)

**Quando usar:** Corrupção severa, migração, ou reset completo.

1. **Parar e remover tudo:**
   ```batch
   docker-compose -f E:\openclaw-docker\docker-compose.yml down -v -r
   ```

2. **Redefinir estrutura:**
   ```batch
   mkdir E:\openclaw-docker\data\.openclaw
   cd E:\openclaw-docker
   docker-compose up -d --build
   ```

3. **Restaurar dados:**
   ```batch
   # Copiar backup restaurado para a nova estrutura
   robocopy E:\backups\openclaw\.openclaw\_latest\ E:\openclaw-docker\data\.openclaw\ /E /I /Y
   ```

4. **Verificar integridade:**
   ```batch
   docker-compose ps
   docker system df
   ```

---

## FERRAMENTAS RECOMENDADAS

### 1. BorgBackup (Recomendado)
```bash
# Instalar no Windows (via WSL)
sudo apt install borgbackup

# Criar repositório
borg init --encryption=repokey /mnt/c/backups/openclaw

# Fazer backup
borg create /mnt/c/backups/openclaw/2026-03-25::E:/openclaw-docker/data/.openclaw

# Listar backups
borg list /mnt/c/backups/openclaw
```

### 2. Restic
```batch
# Windows (via scoop ou chocolatey)
scoop install restic

# Criar repositório
restic -r "s3:https://bucket/path" register

# Backup
restic -r "s3:https://bucket/path" backup E:\openclaw-docker\data\.openclaw
```

### 3. Rsync (via WSL)
```bash
# WSL2 (Linux)
sudo apt install rsync

# Backup incremental
rsync -avz -e ssh --delete /mnt/c/openclaw-docker/data/.openclaw/ /mnt/backup/
```

---

## ROTINA RECOMENDADA

### Backup Diário
- **Horário:** 02:00 - 04:00 (janela de baixo uso)
- **Duração:** ~5-15 minutos
- **Frequência:** Diário

### Backup Semanal Completo
- **Domingo:** 03:00
- **Duração:** ~30-60 minutos
- **Ação:** Snapshot completo + compactação

### Backup Mensal de Longo Prazo
- **Último dia do mês:** Preservar snapshots por 3-6 meses
- **Armazenamento:** S3, NAS externo, ou outro local seguro

---

## CHECKLIST DE VALIDAÇÃO

### Pós-Backup
- [ ] Backup concluído sem erros
- [ ] Checksum gerado e validado
- [ ] Tamanho do backup registrado
- [ ] Backup salvo em local seguro (off-site recomendado)
- [ ] Notificação de sucesso enviada (opcional)

### Pós-Restauração
- [ ] Todos os contêineres rodando
- [ ] Conexão estabelecida com Home Assistant
- [ ] Memória carregada corretamente
- [ ] Logs limpos e sem erros
- [ ] Backups verificados após restauração

---

## MONITORAMENTO

### Métricas a Acompanhar
- Tamanho dos backups
- Tempo de backup
- Taxa de erro
- Espaço de armazenamento disponível
- Integridade dos backups

### Alertas Sugeridos
- Backup falhando > 2x consecutivas
- Backup > 100MB em 1 minuto (exagerado)
- Espaço de backup > 80%
- Checksum não correspondente

---

## CONTATO E SUPOORTE

Em caso de problemas:
- **Telegram:** (ID: 1457522952)
- **Discord:** https://discord.com/invite/clawd
- **GitHub:** https://github.com/openclaw/openclaw

---

*Documento gerado para OpenClaw - Última atualização: 2026-03-25*
