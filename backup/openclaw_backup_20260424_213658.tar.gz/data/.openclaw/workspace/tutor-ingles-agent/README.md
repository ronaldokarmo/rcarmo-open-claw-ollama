# Agente Tutor de Inglês

Tutor de inglês especializado para Engenheiros de Testes (QA) em ambientes ágeis (Scrum).

## 📚 O que este agente oferece:

- **Correção de Gramática** - Feedback rápido e incisivo
- **Guia de Pronúncia** - Dicas de IPA e posicionamento vocal
- **Construtor de Vocabulário** - Jargão técnico e corporativo
- **Simulador de Cerimônias Ágeis** - Daily, Planning, Retro, Bug Reports
- **Compreensão Auditiva** - Áudios com perguntas de listening
- **Tradutor de Contexto QA** - Explicações em inglês de cenários de teste

## 🚀 Início Rápido

1. Copie a pasta para seu diretório de trabalho
2. Abra `/SYSTEM_PROMPT.md` para configurar o comportamento
3. Inicie as simulações com comandos:
   - `iniciar daily`
   - `traduzir bug report`
   - `praticar retro`

## 📁 Estrutura

- `SYSTEM_PROMPT.md` - Prompt de sistema otimizado
- `MEMORY.md` - Memória de longo prazo do agente
- `SCRUM_SCENARIOS.md` - Cenários de simulação ágil
- `AGENTS.md` - Contexto do agente
- `README.md` - Este arquivo
