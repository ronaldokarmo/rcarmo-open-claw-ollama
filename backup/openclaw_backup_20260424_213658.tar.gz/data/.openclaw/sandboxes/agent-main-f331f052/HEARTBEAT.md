# HEARTBEAT.md

# Automated Task Checklist for aton (Cyber-Gryphon)

- [ ] **Log Cleanup**: Check the size of `debug.log`. If larger than 50MB, rotate or truncate.
- [ ] **Memory Sync**: Review notes from the last 2 days in `memory/` and distill important learnings into `MEMORY.md`.
- [ ] **Home Assistant Monitor**: Attempt to `curl` the HA link. If it responds again, notify Ronaldo on Telegram.
- [ ] **System Status**: Check host disk space and memory usage.
- [ ] **Proactivity**: If there is anything relevant (e.g., recurring errors in logs or an upcoming event on the calendar), send an alert via Telegram.

# Note: To deactivate the heartbeat, leave this file with only comments.
