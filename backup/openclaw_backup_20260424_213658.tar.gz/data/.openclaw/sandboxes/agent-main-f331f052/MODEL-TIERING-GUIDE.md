# Model Tiering Configuration for OpenClaw

## 🎯 Objective
Implement a sophisticated model tiering system that optimizes cost and performance by using appropriate models for different task complexity levels.

## 📊 Model Tiers

### Tier 1: Economic & Simple Tasks (Cheap Models)
**Use Case**: English lessons, simple Q&A, basic content creation
**Models**: Small, low-cost models
- `ollama/smollm2:1.7b` - 1.7B parameters, fast, low cost
- `ollama/qwen2.5:1.5b` - 1.5B parameters, good for structured tasks
- `ollama/llama3.2:1b` - 1B parameters, minimal cost

### Tier 2: Balanced & General Tasks (Medium Models)
**Use Case**: General conversation, content creation, analysis, moderate complexity
**Models**: Medium-range models with good capabilities
- `openrouter/z-ai/glm-4.5-air:free` - Current main model, good balance
- `ollama/phi3.5` - 3.5B parameters, capable model

### Tier 3: Complex & Advanced Tasks (Premium Models)
**Use Case**: Code generation, IoT setup, automation, complex reasoning
**Models**: High-capability models for demanding tasks
- `openrouter/auto` - Auto-select best available model
- Future: Add premium models for complex tasks

## 🔄 Fallback Chains

### Primary Agent (main) Fallback Chain
1. **Primary**: `openrouter/z-ai/glm-4.5-air:free` (Tier 2 - Balanced)
2. **Fallback 1**: `ollama/phi3.5` (Tier 2 - Alternative balanced)
3. **Fallback 2**: `ollama/smollm2:1.7b` (Tier 1 - Economic)
4. **Fallback 3**: `ollama/qwen2.5:1.5b` (Tier 1 - Alternative economic)

### English Tutor Agent Fallback Chain
1. **Primary**: `ollama/smollm2:1.7b` (Tier 1 - Optimized for lessons)
2. **Fallback 1**: `ollama/qwen2.5:1.5b` (Tier 1 - Alternative)
3. **Fallback 2**: `openrouter/z-ai/glm-4.5-air:free` (Tier 2 - Backup)

### IoT Engineer Agent Fallback Chain
1. **Primary**: `ollama/phi3.5` (Tier 2 - Good for technical tasks)
2. **Fallback 1**: `openrouter/z-ai/glm-4.5-air:free` (Tier 2 - Balanced)
3. **Fallback 2**: `ollama/smollm2:1.7b` (Tier 1 - Economic backup)

## 🎯 Task-Based Model Selection

### Simple Tasks (Use Tier 1)
- English lessons and exercises
- Word/phrase definitions and examples
- Basic grammar explanations
- Simple translations
- General Q&A (non-technical)
- Content summarization (short texts)

### Medium Tasks (Use Tier 2)
- General conversation
- Content creation (articles, stories)
- Analysis and interpretation
- Moderate problem solving
- Code review and explanation
- Configuration file generation

### Complex Tasks (Use Tier 3)
- Automation code generation
- IoT device setup and configuration
- Complex system design
- Advanced debugging
- Performance optimization
- Multi-step workflows

## 📋 Implementation Plan

### 1. Update Agent Configuration
Modify `/home/openclaw/.openclaw/agents/main/agent/models.json` to include fallback chains.

### 2. Create Model Tiering Skill
Create a skill that can dynamically select appropriate models based on task complexity.

### 3. Implement Task Classification
Add logic to classify incoming requests and route them to appropriate model tiers.

### 4. Update Heartbeat Configuration
Ensure heartbeat uses appropriate tier (currently using `ollama/llama3.2:1b` which is good).

### 5. Monitor and Optimize
Track model usage, costs, and performance to fine-tune tier selection.

## 🔧 Configuration Commands

### Apply New Model Configuration
```bash
# Update main agent with fallback chain
openclaw config agents.main.model.primary="openrouter/z-ai/glm-4.5-air:free"
openclaw config agents.main.model.fallbacks="ollama/phi3.5,ollama/smollm2:1.7b,ollama/qwen2.5:1.5b"

# Update English tutor
openclaw config agents.tutor-english.model="ollama/smollm2:1.7b"
openclaw config agents.tutor-english.model.fallbacks="ollama/qwen2.5:1.5b,openrouter/z-ai/glm-4.5-air:free"

# Update IoT engineer  
openclaw config agents.tutor-iot.model="ollama/phi3.5"
openclaw config agents.tutor-iot.model.fallbacks="openrouter/z-ai/glm-4.5-air:free,ollama/smollm2:1.7b"
```

### Verify Configuration
```bash
# Check agent model configuration
openclaw config agents.main.model
openclaw config agents.tutor-english.model  
openclaw config agents.tutor-iot.model

# Test model availability
openclaw models list
openclaw models test openrouter/z-ai/glm-4.5-air:free
openclaw models test ollama/smollm2:1.7b
```

## 💰 Cost Optimization Strategy

### Expected Cost Reduction
- **English Lessons**: 60-80% cost reduction using Tier 1 models
- **General Tasks**: Maintain current quality with Tier 2 models
- **Complex Tasks**: Use premium models only when necessary

### Monitoring Setup
```bash
# Monitor model usage and costs
openclaw status --cost
openclaw logs --model-usage

# Set up cost alerts
openclaw config monitoring.costAlertThreshold="10"  # $10 daily limit
```

## 📈 Performance Metrics

### Success Metrics to Track
1. **Task Success Rate** by tier
2. **Response Time** by model
3. **Cost per Task** by complexity
4. **User Satisfaction** by task type
5. **Fallback Usage** frequency

### Benchmarking
```bash
# Benchmark models for specific tasks
openclaw benchmark --task="english-lesson" --models="smollm2:1.7b,glm-4.5-air:free"
openclaw benchmark --task="code-generation" --models="phi3.5,glm-4.5-air:free"
```

---

*Created: March 4, 2026*
*Version: 1.0*
*Target Implementation: Immediate*