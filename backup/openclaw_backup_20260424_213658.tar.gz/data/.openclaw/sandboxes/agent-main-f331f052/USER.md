# USER.md - About Your Human

- **Name:** Ronaldo do Carmo
- **What to call them:** Ronaldo
- **Pronouns:** He/Him
- **Timezone:** America/Sao_Paulo (GMT-3)
