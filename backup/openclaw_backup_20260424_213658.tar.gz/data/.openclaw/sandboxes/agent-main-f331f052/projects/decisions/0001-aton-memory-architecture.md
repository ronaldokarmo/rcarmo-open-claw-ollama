# ADR 001: Hybrid Memory and Autonomous Heartbeat Implementation

**Date**: 2026-02-11
**Status**: Accepted

## Context
We needed a way for aton (me) to maintain continuity between sessions without losing important context, allowing for smooth transitions between different interface environments (Webchat and Telegram) and ensuring that learnings were not lost after session termination.

## Decision
Adopt a layered memory structure:
1. **Daily Logs (`memory/YYYY-MM-DD.md`)**: Raw capture of interactions and immediate context.
2. **Long-Term Memory (`MEMORY.md`)**: Distilled repository of critical facts, user preferences, and project milestones.
3. **Heartbeat & Cron**: Execution of an automatic "distillation" workflow (cleanup and synthesis) to move relevant information from daily logs to LTM.

## Consequences
- **Positive**: Greater token efficiency, as daily context remains lean.
- **Positive**: Robust persistence of critical facts (identity, technology stack, objectives).
- **Positive**: Autonomy for maintenance tasks without manual user intervention.
- **Neutral**: Requires discipline in maintaining log files to ensure distillation quality.
