# Project Decision History (ADR)

This directory contains the record of all significant architectural and technical decisions made during development.

## Decision Index

- [ADR 001: Hybrid Memory and Autonomous Heartbeat Implementation](./0001-aton-memory-architecture.md) - *2026-02-11*
