# Log Analysis Skill

## Purpose

Analyze logs to detect errors, anomalies, and performance issues.

## When to Use

- Unexpected crashes
- Performance degradation
- Security investigation
- Debugging sessions

## Steps

1. Identify log source:
   - Application logs
   - Docker logs
   - System logs

2. Extract recent errors:

   grep -i error <logfile>

3. Extract warnings:

   grep -i warn <logfile>

4. Detect patterns:
   - Repeated stack traces
   - Timeout errors
   - Connection refused
   - Memory leaks

5. Summarize findings.

## Output Requirements

- Error categories
- Frequency
- Timeline
- Suspected root cause
- Recommended action
