# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Home Assistant
- **URL**: http://rcarmo-iot.duckdns.org:8123/

### Interruptores (Mapeamento GeneralA)
- **switch.generala_switch_1** → Cozinha 🍳
- **switch.generala_switch_2** → Corredor 🚶‍♂️
- **switch.generala_switch_3** → Lavanderia 🧺

### Outros Dispositivos Identificados
- **light.generalc_luz_de_fundo**
- **Escritório**, **Repelente**, **Desktop**
- **switch.energy_meter_f1_interruptor** (Energy Meter)

---
*Nota: Use estes apelidos para comandos de voz ou automações.*
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.
