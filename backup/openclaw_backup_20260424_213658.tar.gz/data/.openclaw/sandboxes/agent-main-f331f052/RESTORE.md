# RESTORE.md - How to Restore Atlas 🦅

## When to Use?
When Atlas is reinstalled from scratch (fresh install) and needs to recover memories, settings, and personality.

---

## Prerequisites
- The backup must be located at `E:\backup-atlas` (mounted as `/mnt/e-drive/backup-atlas/` inside the Docker container)
- OpenClaw must be running (even if it's a clean installation)

---

## Option 1: Automatic (recommended)
Simply send this message to Atlas on Telegram or webchat:

> **"Restore your memories and settings from the backup at E:\backup-atlas"**

He knows what to do. He will read this file and follow the steps below on his own.

---

## Option 2: Manual (step by step)

### 1. Restore the Workspace (memories, identity, projects)
```bash
cp -rv /mnt/e-drive/backup-atlas/workspace/* /home/openclaw/.config/openclaw/.openclaw/workspace/
```

### 2. Restore Telegram Credentials
```bash
cp /mnt/e-drive/backup-atlas/credentials/telegram-allowFrom.json /home/openclaw/.config/openclaw/.openclaw/credentials/
cp /mnt/e-drive/backup-atlas/credentials/telegram-pairing.json /home/openclaw/.config/openclaw/.openclaw/credentials/
```

### 3. Restore Telegram Offset
```bash
mkdir -p /home/openclaw/.config/openclaw/.openclaw/telegram
cp /mnt/e-drive/backup-atlas/telegram/update-offset-default.json /home/openclaw/.config/openclaw/.openclaw/telegram/
```

### 4. Apply Settings (via webchat or CLI)
The following configs need to be applied to `openclaw.json` (via `config.patch` or manual editing):

- **Telegram bot token** and plugin enabled
- **Qwen Portal** as provider (coder-model + vision-model)
- **Brave Search API key**
- **Identity links** (telegram:1457522952 → main)
- **Session/channel configs**

> ⚠️ **Do not copy the `openclaw.json` from backup directly** — paths and versions may have changed. Perform a **merge** of the configurations.

### 5. Recreate Cron Jobs
The backup had:
- **Weekly Memory Distillation** — every Monday, 9am BRT
  - Cron: `0 9 * * 1` (tz: America/Sao_Paulo)
  - Type: isolated `agentTurn` with `announce` delivery

### 6. Restart the Gateway
```bash
openclaw gateway restart
```

---

## Backup Structure

```
E:\backup-atlas/
├── workspace/          # Memories, identity, projects, glossary
│   ├── MEMORY.md       # Long-term memory
│   ├── SOUL.md         # Personality
│   ├── IDENTITY.md     # Name, creature, emoji
│   ├── USER.md         # Ronaldo's data
│   ├── HEARTBEAT.md    # Automated tasks
│   ├── TOOLS.md        # Tool notes
│   ├── memory/         # Daily diaries
│   ├── dictionary/     # EN/PT glossary
│   ├── projects/       # Decisions and projects
│   └── snippets/       # Test snippets
├── credentials/        # Telegram allowFrom + pairing
├── telegram/           # Update offset
├── cron/               # Scheduled jobs
├── openclaw.json       # Config (reference, DO NOT copy directly)
└── devices/            # Paired devices
```

---

## How to Keep the Backup Updated

Periodically (or before any major change), run:

```bash
# Copy updated workspace to backup
cp -rv /home/openclaw/.config/openclaw/.openclaw/workspace/* /mnt/e-drive/backup-atlas/workspace/

# Copy current config
cp /home/openclaw/.config/openclaw/.openclaw/openclaw.json /mnt/e-drive/backup-atlas/openclaw.json

# Copy credentials
cp /home/openclaw/.config/openclaw/.openclaw/credentials/* /mnt/e-drive/backup-atlas/credentials/

# Copy cron jobs
cp /home/openclaw/.config/openclaw/.openclaw/cron/* /mnt/e-drive/backup-atlas/cron/
```

> 💡 **Tip**: Asking Atlas to back up is easier — "Atlas, back up your configs."

---

*Created on: 2026-02-13*
*Last restoration: 2026-02-13 (successful ✅)*
