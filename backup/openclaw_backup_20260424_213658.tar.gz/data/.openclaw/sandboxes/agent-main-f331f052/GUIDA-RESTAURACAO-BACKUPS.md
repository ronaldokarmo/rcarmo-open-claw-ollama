# Guia de Restauração de Backups - OpenClaw & Docker

## 📋 Sumário

- [Visão Geral](#visão-geral)
- [Backup Disponíveis](#backup-disponíveis)
- [Preparação para Restauração](#preparação-para-restauração)
- [Restauração do OpenClaw](#restauração-do-openclaw)
- [Restauração do Docker](#restauração-do-docker)
- [Configuração Pós-Restauração](#configuração-pós-restauração)
- [Verificação Final](#verificação-final)
- [Troubleshooting](#troubleshooting)

---

## 🎯 Visão Geral

Este guia detalha o processo completo de restauração dos backups do OpenClaw e Docker. Os backups incluem:

1. **OpenClaw completo** - Configurações, agents, workspace, skills, logs, sessões
2. **Docker** - Configurações de containers e skills de monitoramento

---

## 📦 Backup Disponíveis

Todos os backups estão localizados em: `/home/openclaw/.openclaw/backups/`

### Backup Principal (OpenClaw)
- **Nome**: `openclaw-backup-20260304_003458.tar.gz`
- **Tamanho**: 847 KB
- **Conteúdo**: Tudo necessário para operação completa do OpenClaw

### Backup Docker
- **Nome**: `docker-backup-20260304_004351.tar.gz`
- **Tamanho**: 813 bytes
- **Conteúdo**: Configurações Docker específicas do OpenClaw

---

## 🛠️ Preparação para Restauração

### 1. Verificar Espaço em Disco
```bash
df -h
```

### 2. Parar Serviços Atuais (se estiverem rodando)
```bash
# Parar OpenClaw
openclaw gateway stop 2>/dev/null || true
# Ou se usando systemd
systemctl --user stop openclaw-gateway 2>/dev/null || true
```

### 3. Backup Atual (opcional)
```bash
# Criar backup do estado atual antes da restauração
tar -czf /tmp/estado-anterior-$(date +%Y%m%d_%H%M%S).tar.gz /home/openclaw/.openclaw/ 2>/dev/null || echo "Backup do estado atual falhou"
```

---

## 🔧 Restauração do OpenClaw

### Passo 1: Extrair o Backup Principal
```bash
cd /home/openclaw
tar -xzf .openclaw/backups/openclaw-backup-20260304_003458.tar.gz
```

### Passo 2: Restaurar Permissões (CRÍTICO)
```bash
# Corrigir permissões de arquivos críticos
chmod 600 /home/openclaw/.openclaw/openclaw.json
chmod 600 /home/openclaw/.openclaw/agents/main/agent/auth-profiles.json

# Ajustar permissões do workspace e diretórios principais
chmod -R 755 /home/openclaw/.openclaw/workspace/
chmod -R 755 /home/openclaw/.openclaw/skills/
chmod -R 755 /home/openclaw/.openclaw/agents/
```

### Passo 3: Verificar Estrutura
```bash
# Verificar se os principais diretórios foram restaurados
ls -la /home/openclaw/.openclaw/
ls -la /home/openclaw/.openclaw/agents/
ls -la /home/openclaw/.openclaw/workspace/
```

### Passo 4: Configurar Gateway
```bash
# Instalar e iniciar gateway
openclaw gateway install
openclaw gateway start

# Verificar status
openclaw status
```

---

## 🐋 Restauração do Docker

### Passo 1: Extrair o Backup Docker
```bash
cd /home/openclaw
tar -xzf .openclaw/backups/docker-backup-20260304_004351.tar.gz
```

### Passo 2: Restaurar Arquivos Docker
Os seguintes arquivos serão restaurados:
- `/home/openclaw/.openclaw/sandbox/containers.json`
- `/home/openclaw/.openclaw/sandboxes/agent-main-f331f052/skills/docker-monitoring/`
- `/home/openclaw/.openclaw/skills/docker-monitoring/`

### Passo 3: Configurar Acesso ao Docker (se necessário)
```bash
# Adicionar usuário ao grupo docker
sudo usermod -aG docker $USER

# Re-login ou reiniciar sessão para aplicar alterações
# Em WSL2, reinicie o WSL: wsl --shutdown (do PowerShell)
```

### Passo 4: Iniciar Docker Daemon
```bash
# Habilitar Docker (se systemd estiver disponível)
sudo systemctl enable docker
sudo systemctl start docker

# Verificar status
sudo docker --version
sudo docker ps
```

---

## ⚙️ Configuração Pós-Restauração

### 1. Verificar Configurações
```bash
# Verificar configuração principal
cat /home/openclaw/.openclaw/openclaw.json

# Verificar status do gateway
openclaw gateway status
```

### 2. Testar Canais
```bash
# Testar conexão com dashboard
curl -s http://127.0.0.1:18791/ | head -5

# Verificar status dos canais
openclaw status
```

### 3. Restaurar Credenciais
```bash
# Verificar se as credenciais foram restauradas
ls -la /home/openclaw/.openclaw/credentials/
```

### 4. Testar Sessões
```bash
# Listar sessões ativas
openclaw status | grep Sessions

# Iniciar uma nova sessão de teste
openclaw chat
```

---

## ✅ Verificação Final

### Checklist de Verificação

| Item | Comando | Status Esperado |
|------|---------|----------------|
| OpenClaw Gateway | `openclaw gateway status` | Running |
| Dashboard | `curl -s http://127.0.0.1:18791/` | Resposta 200 |
| Agent Principal | `openclaw status \| grep main` | Active |
| Telegram | `openclaw status \| grep Telegram` | OK |
| Docker Access | `docker ps` | Lista containers |
| Permissões | `ls -la /home/openclaw/.openclaw/openclaw.json` | -rw------- |
| Workspace | `ls -la /home/openclaw/.openclaw/workspace/` | Arquivos visíveis |

### Comandos de Diagnóstico
```bash
# Status completo
openclaw status

# Logs de gateway
tail -f /tmp/openclaw/openclaw-*.log

# Verificar permissões
ls -la /home/openclaw/.openclaw/

# Testar conectividade
curl -I http://127.0.0.1:18791/
```

---

## 🚨 Troubleshooting

### Problema: Permissão Negada ao Abrir OpenClaw
```bash
# Solução: Corrigir permissões
chmod 600 /home/openclaw/.openclaw/openclaw.json
chmod -R 755 /home/openclaw/.openclaw/
```

### Problema: Gateway Não Inicia
```bash
# Solução: Verificar logs e reiniciar
tail -f /tmp/openclaw/openclaw-*.log
openclaw gateway stop
openclaw gateway start
```

### Problema: Docker Daemon Não Responde
```bash
# Solução: Reiniciar Docker
sudo systemctl restart docker
# Ou em WSL2: reiniciar WSL
```

### Problema: Workspace Vazio
```bash
# Solução: Verificar se o backup foi extraído no local correto
ls -la /home/openclaw/.openclaw/workspace/
```

### Problema: Sessões Não Funcionam
```bash
# Solução: Verificar modelo e configuração
openclaw status
cat /home/openclaw/.openclaw/agents/main/agent/models.json
```

---

## 📞 Suporte

Se você encontrar problemas durante a restauração:

1. **Verificar Logs**: `/tmp/openclaw/openclaw-*.log`
2. **Status Completo**: `openclaw status`
3. **Diagnóstico**: `openclaw doctor`
4. **Documentação**: https://docs.openclaw.ai/troubleshooting

---

## 📝 Notas Importantes

- **Ordem de Restauração**: Sempre restaurar OpenClaw primeiro, depois Docker
- **Permissões**: Nunca use `chmod 777` em arquivos de configuração
- **WSL2**: Se estiver usando WSL2, pode ser necessário reiniciar o WSL após alterações de grupo
- **Credenciais**: Verifique se suas chaves de API e tokens foram restaurados corretamente
- **Backup Original**: Mantenha os arquivos .tar.gz originais como camada extra de segurança

---

*Última Atualização: 04 de março de 2026*
*Versão: 1.0*