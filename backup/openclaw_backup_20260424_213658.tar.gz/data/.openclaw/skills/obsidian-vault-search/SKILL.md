---
name: obsidian-vault-search
description: Busca e consulta notas no Obsidian Vault montado em /home/openclaw/obsidian. Use quando o usuário perguntar sobre informações armazenadas no vault, quiser buscar notas, consultar Knowledge, Memory ou Projects. Triggers: "buscar no vault", "consultar notas", "obsidian", "knowledge base", "o que eu tenho sobre", "notas sobre".
---

# Obsidian Vault Search

## Purpose

Search and retrieve information from the Obsidian vault mounted at `$OBSIDIAN_VAULT_PATH` (/home/openclaw/obsidian).

## Vault Structure

- **Knowledge/** — Base de conhecimento permanente (conceitos, referências)
- **Memory/** — Memória operacional (comandos úteis, preferências, setup)
- **Projects/** — Notas de projetos ativos

## When to Use

- User asks about stored knowledge or notes
- User wants to find information in their vault
- User references "vault", "obsidian", "notas", or "knowledge"
- User asks "o que eu tenho sobre X?"

## Steps

1. Identify the search intent and keywords from the user's message

2. Search across all vault directories:
   ```bash
   grep -ril "<keywords>" /home/openclaw/obsidian/ --include="*.md" 2>/dev/null
   ```

3. If results found, read the relevant files:
   ```bash
   cat "/home/openclaw/obsidian/<path>/<file>.md"
   ```

4. If no grep results, list available notes for context:
   ```bash
   find /home/openclaw/obsidian -name "*.md" -not -path "*/.obsidian/*" | sort
   ```

5. Summarize findings clearly, referencing the source file

## Output Requirements

- Always mention which file(s) the information came from
- If no results found, list available topics
- Suggest creating a new note if the topic doesn't exist
- Use Portuguese (pt-BR) for responses

## Configuration

- **vault_path**: $OBSIDIAN_VAULT_PATH (default: /home/openclaw/obsidian)
- **read_only**: false (can suggest creating new notes)
- **response_language**: pt-BR
