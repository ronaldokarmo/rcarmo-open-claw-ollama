# English Tutor Skill

## Metadata

- **name**: english-tutor
- **description**: Avalia pronúncia, naturalidade, vocabulário, compreensão e gramática de áudio/texto em inglês baseado nos 5 pilares da fluência
- **version**: 1.0.0
- **author**: Ronaldo do Carmo
- **language**: pt-BR (feedback em português)

## Triggers

- **patterns**:
  - `!english` - Ativa avaliação da próxima mensagem
  - `!ingles` - Alias em português
  - `!avaliar` - Alias genérico
  - `!fluência` - Alias temático
- **languages**: ["en"] - Auto-detecta conteúdo em inglês
- **input_types**: ["text", "voice", "audio"]

## Behavior

- **mode**: evaluate
- **output_format**: structured_feedback
- **activate_on**: message_after_trigger (ativa na mensagem seguinte ao trigger)

## Configuration

- **response_language**: pt-BR
- **create_thread**: false (responde inline)
- **models**:
  - **default**: kimi (nvidia-nim/moonshotai/kimi-k2.5)

## Notes

- Feedback deve ser construtivo, encorajador e prático
- Para áudio: transcrever primeiro, depois avaliar os 5 pilares
- Para texto: avaliar apenas VOCABULÁRIO, COMPREENSÃO e GRAMÁTICA (PRONÚNCIA e NATURALIDADE = N/A)
- Sempre incluir uma frase modelo para prática
- Manter tom de professor paciente e motivador
