---
name: Docker Monitor
description: 
---

# Docker Monitoring Skill

## Purpose

Monitor Docker containers health, status, and resource usage.

## When to Use

- Performance degradation
- Container crash
- Deployment validation
- Health checks

## Steps

1. List running containers:

   docker ps

2. List all containers:

   docker ps -a

3. Inspect container:

   docker inspect <container_name>

4. Check resource usage:

   docker stats --no-stream

5. View recent logs:

   docker logs <container_name> --tail 100

## Output Requirements

- Identify unhealthy containers
- Identify high CPU or memory usage
- Detect restart loops
- Provide action recommendations
