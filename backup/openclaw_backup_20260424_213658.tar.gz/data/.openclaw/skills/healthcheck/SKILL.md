---
name: Healthceck
description: <descrição>
---

# Health Check Skill

## Purpose

This skill verifies if the system is running correctly and checks basic health indicators.

## When to Use

- When the user asks to verify system status
- After container restarts
- When troubleshooting

## Steps

1. Check if Docker is running:

   docker ps

2. Check container logs:

   docker logs openclaw --tail 50

3. Check disk usage:

   df -h

4. Report findings clearly.

## Expected Output

- Inform if containers are running
- Inform if errors are detected
- Suggest corrective actions if needed
