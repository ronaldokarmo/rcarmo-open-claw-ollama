---
name: Automated Testing
description: <descrição>
---

# Automated Testing Skill

## Purpose

Execute and validate automated tests for applications or services.

## When to Use

- Before deployment
- After code changes
- CI/CD validation
- Regression analysis

## Steps

1. Identify test framework (pytest, jest, junit, etc.)

2. Run test suite:

   pytest

   or

   npm test

   or

   mvn test

3. Collect:
   - Passed tests
   - Failed tests
   - Error traces

4. Analyze failures:
   - Assertion errors
   - Timeout
   - Dependency issues

## Output Requirements

- Total tests
- Passed / Failed count
- Root cause of failures
- Suggested fixes
