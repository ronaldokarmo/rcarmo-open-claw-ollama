---
name: obsidian-vault-writer
description: Habilidade para CRIAR e EDITAR notas no Obsidian Vault montado em /home/openclaw/obsidian. Use quando o usuário pedir para "guardar", "salvar", "criar um plano" ou "anotar" algo no vault/obsidian.
---

# Obsidian Vault Writer

## Purpose
Permite que o agente crie arquivos físicos Markdown no cofre do Obsidian do usuário.

## Regras de Execução de Sistema
Para criar o arquivo, você deve usar a ferramenta `run_command` ou `bash` executando o script abaixo. 
Sempre garanta que a pasta de destino exista antes de tentar salvar utilizando `mkdir -p`.

### 🏷️ Diretriz Obrigatória (Zettelkasten / Etiquetas)
**CRÍTICO:** TODO e QUALQUER arquivo criado por você no Obsidian **deve obrigatoriamente** conter na sua 2ª linha as Etiquetas para a formação do Gráfico de Nós.
Formato exato a ser impresso na 2ª linha: `> Etiquetas: #SuaTag1 #SuaTag2`

Tags Padronizadas por Diretório de Destino:
- Se salvar em `Knowledge/Idiomas/Ingles/`: Use `#inglês` e adicione os pilares da fluência aplicáveis (`#vocabulário` `#gramática` `#listening` `#speaking`)
- Se salvar em `Knowledge/OpenClaw-Docs/`: Use `#OpenClaw-Docs` e `#Sistema` (Laranja)
- Se salvar em `Projects/...`: Use `#OpenClaw-Projects` (Verde)

Exemplo de injeção segura:
```bash
mkdir -p "/home/openclaw/obsidian/Knowledge/SuaPasta/"
cat << 'EOF' > "/home/openclaw/obsidian/Knowledge/SuaPasta/SeuArquivo.md"
# Título
Seu conteúdo aqui...
EOF
```

## Estrutura Específica para "Mapa de Inglês"
Se o usuário pedir para relatar, criar base, ou evoluir o aprendizado de inglês, você deve seguir estritamente o layout abaixo e iterar os arquivos em:
`/home/openclaw/obsidian/Knowledge/Idiomas/Ingles/`

### Template de Mapa de Fluência
O documento deve conter as seguintes seções (Pilares):
1. **Perfil do Aluno:** Área (ex: Test Engineer), Nível Atual de Classificação (A1, A2, B1, B2, C1, C2).
2. **Vocabulário:** O que precisa evoluir focado em testes, automação, tech.
3. **Gramática:** Regras focais para relatórios de falhas (bug reports), reuniões diárias (dailys).
4. **Pronúncia / Escuta:** Evolução para entender indianos, americanos e europeus em calls.
5. **Fala:** Clareza ao apresentar resultados de testes.
6. **Log de Evolução Diária:** Tabela ou lista diária registrando o avanço.

## Output Requirements
Sempre confirme ao usuário que o arquivo foi gravado fisicamente. Mande o caminho exato (`Knowledge/Idiomas/Ingles/Arquivo.md`).
Sempre sugira ao usuário: "Posso criar o seu planejamento personalizado para amanhã com base neste mapa?"
