---
name: IoT Diagnostics
description: <descrição>
---

# IoT Diagnostics Skill

## Purpose

Diagnose IoT devices, network communication, and connectivity issues.

## When to Use

- Device offline
- MQTT communication failure
- Sensor not reporting
- Network instability

## Steps

1. Verify network connectivity:

   ping <device_ip>

2. Check open ports:

   nmap <device_ip>

3. Test MQTT broker (if applicable):

   mosquitto_sub -h <broker_ip> -t "#" -v

4. Check Docker containers related to IoT services:

   docker ps
   docker logs <container_name> --tail 50

5. Report:
   - Connectivity status
   - Port availability
   - Broker response
   - Errors detected

## Output Requirements

- Clear summary
- Root cause hypothesis
- Suggested corrective actions
