# Tutoriais

Este diretório contém tutoriais para agentes especiais da plataforma OpenClaw:

## Agentes

- [tutor-english](./tutor-english.md) - Criação de conteúdo em inglês
- [tutor-iot](./tutor-iot.md) - Projetos Arduino, ESP32 e eletrônica
- [prompt-engineer](./prompt-engineer.md) - Engenharia de prompts otimizados
- [main](./main.md) - Agente principal da plataforma

## Tutorials Específicos

### Inglês
- [5 pilares do aprendizado](./tutor-english-pilares.md)

### IoT
- [Código Arduino completo](./tutor-iot.md)

### Prompt Engineering
- [Otimização de prompts](./prompt-engineer.md)
