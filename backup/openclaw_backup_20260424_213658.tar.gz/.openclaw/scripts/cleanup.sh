#!/bin/bash
# Script de limpeza para OpenClaw

DATA_DIR="${DATA_DIR:-/home/openclaw/.openclaw}"
CACHE_DIR="${CACHE_DIR:-/home/openclaw/.openclaw/cache}"
MAX_CACHE_SIZE="${MAX_CACHE_SIZE:-100M}"
MAX_CACHE_AGE="${MAX_CACHE_AGE:-7d}"

echo "🧹 Iniciando limpeza do sistema OpenClaw..."

# Limpar cache antigo
echo "📦 Limpando cache > ${MAX_CACHE_AGE}..."
find "$CACHE_DIR" -type f -name "*.cache" -mtime +${MAX_CACHE_AGE} -delete 2>/dev/null
echo "✅ Cache antigo removido"

# Verificar tamanho atual
if [ -d "$CACHE_DIR" ]; then
    cache_size=$(du -sh "$CACHE_DIR" 2>/dev/null | cut -f1)
    echo "📊 Tamanho atual do cache: $cache_size"

    if [ "${cache_size}" != "0" ] && [ "${cache_size}" -gt 100 ]; then
        echo "⚠️  Cache grande: ${cache_size}. Considera aumentar MAX_CACHE_SIZE ou aumentar cache size."
    fi
fi

# Limpar logs antigos
LOG_DIR="/var/log/openclaw"
echo "📦 Limpando logs > 7 dias..."
find "$LOG_DIR" -name "*.log*" -type f -mtime +7 -delete 2>/dev/null
echo "✅ Logs antigos removidos"

echo "✅ Limpeza concluída!"